#!/bin/bash
wget http://www.eecs70.org/static/slides/lec-$1.pdf
