#!/bin/bash
wget http://www.eecs70.org/static/notes/$1.pdf